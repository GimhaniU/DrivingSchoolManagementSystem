/* ====================================================================
 *
 * Skin Look And Feel 1.2.3 License.
 *
 * Copyright (c) 2000-2002 L2FProd.com.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by L2FProd.com
 *        (http://www.L2FProd.com/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Skin Look And Feel", "SkinLF" and "L2FProd.com" must not
 *    be used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact info@L2FProd.com.
 *
 * 5. Products derived from this software may not be called "SkinLF"
 *    nor may "SkinLF" appear in their names without prior written
 *    permission of L2FProd.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL L2FPROD.COM OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package com.l2fprod.gui.plaf.skin.impl.gtk.parser;

/**
 * An implementation of interface CharStream, where the stream is assumed to
 * contain only ASCII characters (with java-like unicode escape processing).
 *
 * @author    fred
 * @created   27 avril 2002
 */

public final class ASCII_UCodeESC_CharStream {

  /**
   * Description of the Field
   */
  public int bufpos = -1;
  int bufsize;
  int available;
  int tokenBegin;
  private int bufline[];
  private int bufcolumn[];

  private int column = 0;
  private int line = 1;

  private java.io.Reader inputStream;

  private boolean prevCharIsCR = false;
  private boolean prevCharIsLF = false;

  private char[] nextCharBuf;
  private char[] buffer;
  private int maxNextCharInd = 0;
  private int nextCharInd = -1;
  private int inBuf = 0;
  /**
   * Description of the Field
   */
  public final static boolean staticFlag = false;

  /**
   * Constructor for the ASCII_UCodeESC_CharStream object
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   * @param buffersize   Description of Parameter
   */
  public ASCII_UCodeESC_CharStream(java.io.Reader dstream,
      int startline, int startcolumn, int buffersize) {
    inputStream = dstream;
    line = startline;
    column = startcolumn - 1;

    available = bufsize = buffersize;
    buffer = new char[buffersize];
    bufline = new int[buffersize];
    bufcolumn = new int[buffersize];
    nextCharBuf = new char[4096];
  }

  /**
   * Constructor for the ASCII_UCodeESC_CharStream object
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   */
  public ASCII_UCodeESC_CharStream(java.io.Reader dstream,
      int startline, int startcolumn) {
    this(dstream, startline, startcolumn, 4096);
  }

  /**
   * Constructor for the ASCII_UCodeESC_CharStream object
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   * @param buffersize   Description of Parameter
   */
  public ASCII_UCodeESC_CharStream(java.io.InputStream dstream, int startline,
      int startcolumn, int buffersize) {
    this(new java.io.InputStreamReader(dstream), startline, startcolumn, 4096);
  }

  /**
   * Constructor for the ASCII_UCodeESC_CharStream object
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   */
  public ASCII_UCodeESC_CharStream(java.io.InputStream dstream, int startline,
      int startcolumn) {
    this(dstream, startline, startcolumn, 4096);
  }

  /**
   * @return       The Column value
   * @deprecated
   * @see          #getEndColumn
   */

  public final int getColumn() {
    return bufcolumn[bufpos];
  }

  /**
   * @return       The Line value
   * @deprecated
   * @see          #getEndLine
   */

  public final int getLine() {
    return bufline[bufpos];
  }

  /**
   * Gets the EndColumn attribute of the ASCII_UCodeESC_CharStream object
   *
   * @return   The EndColumn value
   */
  public final int getEndColumn() {
    return bufcolumn[bufpos];
  }

  /**
   * Gets the EndLine attribute of the ASCII_UCodeESC_CharStream object
   *
   * @return   The EndLine value
   */
  public final int getEndLine() {
    return bufline[bufpos];
  }

  /**
   * Gets the BeginColumn attribute of the ASCII_UCodeESC_CharStream object
   *
   * @return   The BeginColumn value
   */
  public final int getBeginColumn() {
    return bufcolumn[tokenBegin];
  }

  /**
   * Gets the BeginLine attribute of the ASCII_UCodeESC_CharStream object
   *
   * @return   The BeginLine value
   */
  public final int getBeginLine() {
    return bufline[tokenBegin];
  }

  /**
   * Description of the Method
   *
   * @return   Description of the Returned Value
   */
  public final String GetImage() {
    if (bufpos >= tokenBegin) {
      return new String(buffer, tokenBegin, bufpos - tokenBegin + 1);
    }
    else {
      return new String(buffer, tokenBegin, bufsize - tokenBegin) +
          new String(buffer, 0, bufpos + 1);
    }
  }

  /**
   * Description of the Method
   *
   * @param len  Description of Parameter
   * @return     Description of the Returned Value
   */
  public final char[] GetSuffix(int len) {
    char[] ret = new char[len];

    if ((bufpos + 1) >= len) {
      System.arraycopy(buffer, bufpos - len + 1, ret, 0, len);
    }
    else {
      System.arraycopy(buffer, bufsize - (len - bufpos - 1), ret, 0,
          len - bufpos - 1);
      System.arraycopy(buffer, 0, ret, len - bufpos - 1, bufpos + 1);
    }

    return ret;
  }

  /**
   * Description of the Method
   *
   * @return                         Description of the Returned Value
   * @exception java.io.IOException  Description of Exception
   */
  public final char BeginToken() throws java.io.IOException {
    if (inBuf > 0) {
      --inBuf;
      return buffer[tokenBegin = (bufpos == bufsize - 1) ? (bufpos = 0)
          : ++bufpos];
    }

    tokenBegin = 0;
    bufpos = -1;

    return readChar();
  }

  /**
   * Description of the Method
   *
   * @return                         Description of the Returned Value
   * @exception java.io.IOException  Description of Exception
   */
  public final char readChar() throws java.io.IOException {
    if (inBuf > 0) {
      --inBuf;
      return buffer[(bufpos == bufsize - 1) ? (bufpos = 0) : ++bufpos];
    }

    char c;

    if (++bufpos == available) {
      AdjustBuffSize();
    }

    if (((buffer[bufpos] = c = (char) ((char) 0xff & ReadByte())) == '\\')) {
      UpdateLineColumn(c);

      int backSlashCnt = 1;

      for (; ; ) {
        // Read all the backslashes

        if (++bufpos == available) {
          AdjustBuffSize();
        }

        try {
          if ((buffer[bufpos] = c = (char) ((char) 0xff & ReadByte())) != '\\') {
            UpdateLineColumn(c);
            // found a non-backslash char.
            if ((c == 'u') && ((backSlashCnt & 1) == 1)) {
              if (--bufpos < 0) {
                bufpos = bufsize - 1;
              }

              break;
            }

            backup(backSlashCnt);
            return '\\';
          }
        } catch (java.io.IOException e) {
          if (backSlashCnt > 1) {
            backup(backSlashCnt);
          }

          return '\\';
        }

        UpdateLineColumn(c);
        backSlashCnt++;
      }

      // Here, we have seen an odd number of backslash's followed by a 'u'
      try {
        while ((c = (char) ((char) 0xff & ReadByte())) == 'u') {
          ++column;
        }

        buffer[bufpos] = c = (char) (hexval(c) << 12 |
            hexval((char) ((char) 0xff & ReadByte())) << 8 |
            hexval((char) ((char) 0xff & ReadByte())) << 4 |
            hexval((char) ((char) 0xff & ReadByte())));

        column += 4;
      } catch (java.io.IOException e) {
        throw new Error("Invalid escape character at line " + line +
            " column " + column + ".");
      }

      if (backSlashCnt == 1) {
        return c;
      }
      else {
        backup(backSlashCnt - 1);
        return '\\';
      }
    }
    else {
      UpdateLineColumn(c);
      return (c);
    }
  }

  /**
   * Description of the Method
   *
   * @param amount  Description of Parameter
   */
  public final void backup(int amount) {

    inBuf += amount;
    if ((bufpos -= amount) < 0) {
      bufpos += bufsize;
    }
  }

  /**
   * Description of the Method
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   * @param buffersize   Description of Parameter
   */
  public void ReInit(java.io.Reader dstream,
      int startline, int startcolumn, int buffersize) {
    inputStream = dstream;
    line = startline;
    column = startcolumn - 1;

    if (buffer == null || buffersize != buffer.length) {
      available = bufsize = buffersize;
      buffer = new char[buffersize];
      bufline = new int[buffersize];
      bufcolumn = new int[buffersize];
      nextCharBuf = new char[4096];
    }
    prevCharIsLF = prevCharIsCR = false;
    tokenBegin = inBuf = maxNextCharInd = 0;
    nextCharInd = bufpos = -1;
  }

  /**
   * Description of the Method
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   */
  public void ReInit(java.io.Reader dstream,
      int startline, int startcolumn) {
    ReInit(dstream, startline, startcolumn, 4096);
  }

  /**
   * Description of the Method
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   * @param buffersize   Description of Parameter
   */
  public void ReInit(java.io.InputStream dstream, int startline,
      int startcolumn, int buffersize) {
    ReInit(new java.io.InputStreamReader(dstream), startline, startcolumn, 4096);
  }

  /**
   * Description of the Method
   *
   * @param dstream      Description of Parameter
   * @param startline    Description of Parameter
   * @param startcolumn  Description of Parameter
   */
  public void ReInit(java.io.InputStream dstream, int startline,
      int startcolumn) {
    ReInit(dstream, startline, startcolumn, 4096);
  }

  /**
   * Description of the Method
   */
  public void Done() {
    nextCharBuf = null;
    buffer = null;
    bufline = null;
    bufcolumn = null;
  }

  /**
   * Method to adjust line and column numbers for the start of a token.<BR>
   *
   *
   * @param newLine  Description of Parameter
   * @param newCol   Description of Parameter
   */
  public void adjustBeginLineColumn(int newLine, int newCol) {
    int start = tokenBegin;
    int len;

    if (bufpos >= tokenBegin) {
      len = bufpos - tokenBegin + inBuf + 1;
    }
    else {
      len = bufsize - tokenBegin + bufpos + 1 + inBuf;
    }

    int i = 0;

    int j = 0;

    int k = 0;
    int nextColDiff = 0;
    int columnDiff = 0;

    while (i < len &&
        bufline[j = start % bufsize] == bufline[k = ++start % bufsize]) {
      bufline[j] = newLine;
      nextColDiff = columnDiff + bufcolumn[k] - bufcolumn[j];
      bufcolumn[j] = newCol + columnDiff;
      columnDiff = nextColDiff;
      i++;
    }

    if (i < len) {
      bufline[j] = newLine++;
      bufcolumn[j] = newCol + columnDiff;

      while (i++ < len) {
        if (bufline[j = start % bufsize] != bufline[++start % bufsize]) {
          bufline[j] = newLine++;
        }
        else {
          bufline[j] = newLine;
        }
      }
    }

    line = bufline[j];
    column = bufcolumn[j];
  }

  /**
   * Description of the Method
   *
   * @param wrapAround  Description of Parameter
   */
  private final void ExpandBuff(boolean wrapAround) {
    char[] newbuffer = new char[bufsize + 2048];
    int newbufline[] = new int[bufsize + 2048];
    int newbufcolumn[] = new int[bufsize + 2048];

    try {
      if (wrapAround) {
        System.arraycopy(buffer, tokenBegin, newbuffer, 0, bufsize - tokenBegin);
        System.arraycopy(buffer, 0, newbuffer,
            bufsize - tokenBegin, bufpos);
        buffer = newbuffer;

        System.arraycopy(bufline, tokenBegin, newbufline, 0, bufsize - tokenBegin);
        System.arraycopy(bufline, 0, newbufline, bufsize - tokenBegin, bufpos);
        bufline = newbufline;

        System.arraycopy(bufcolumn, tokenBegin, newbufcolumn, 0, bufsize - tokenBegin);
        System.arraycopy(bufcolumn, 0, newbufcolumn, bufsize - tokenBegin, bufpos);
        bufcolumn = newbufcolumn;

        bufpos += (bufsize - tokenBegin);
      }
      else {
        System.arraycopy(buffer, tokenBegin, newbuffer, 0, bufsize - tokenBegin);
        buffer = newbuffer;

        System.arraycopy(bufline, tokenBegin, newbufline, 0, bufsize - tokenBegin);
        bufline = newbufline;

        System.arraycopy(bufcolumn, tokenBegin, newbufcolumn, 0, bufsize - tokenBegin);
        bufcolumn = newbufcolumn;

        bufpos -= tokenBegin;
      }
    } catch (Throwable t) {
      throw new Error(t.getMessage());
    }

    available = (bufsize += 2048);
    tokenBegin = 0;
  }

  /**
   * Description of the Method
   *
   * @exception java.io.IOException  Description of Exception
   */
  private final void FillBuff() throws java.io.IOException {
    int i;
    if (maxNextCharInd == 4096) {
      maxNextCharInd = nextCharInd = 0;
    }

    try {
      if ((i = inputStream.read(nextCharBuf, maxNextCharInd,
          4096 - maxNextCharInd)) == -1) {
        inputStream.close();
        throw new java.io.IOException();
      }
      else {
        maxNextCharInd += i;
      }
      return;
    } catch (java.io.IOException e) {
      if (bufpos != 0) {
        --bufpos;
        backup(0);
      }
      else {
        bufline[bufpos] = line;
        bufcolumn[bufpos] = column;
      }
      throw e;
    }
  }

  /**
   * Description of the Method
   *
   * @return                         Description of the Returned Value
   * @exception java.io.IOException  Description of Exception
   */
  private final char ReadByte() throws java.io.IOException {
    if (++nextCharInd >= maxNextCharInd) {
      FillBuff();
    }

    return nextCharBuf[nextCharInd];
  }

  /**
   * Description of the Method
   */
  private final void AdjustBuffSize() {
    if (available == bufsize) {
      if (tokenBegin > 2048) {
        bufpos = 0;
        available = tokenBegin;
      }
      else {
        ExpandBuff(false);
      }
    }
    else if (available > tokenBegin) {
      available = bufsize;
    }
    else if ((tokenBegin - available) < 2048) {
      ExpandBuff(true);
    }
    else {
      available = tokenBegin;
    }
  }

  /**
   * Description of the Method
   *
   * @param c  Description of Parameter
   */
  private final void UpdateLineColumn(char c) {
    column++;

    if (prevCharIsLF) {
      prevCharIsLF = false;
      line += (column = 1);
    }
    else if (prevCharIsCR) {
      prevCharIsCR = false;
      if (c == '\n') {
        prevCharIsLF = true;
      }
      else {
        line += (column = 1);
      }
    }

    switch (c) {
      case '\r':
        prevCharIsCR = true;
        break;
      case '\n':
        prevCharIsLF = true;
        break;
      case '\t':
        column--;
        column += (8 - (column & 07));
        break;
      default:
        break;
    }

    bufline[bufpos] = line;
    bufcolumn[bufpos] = column;
  }

  /**
   * Description of the Method
   *
   * @param c                        Description of Parameter
   * @return                         Description of the Returned Value
   * @exception java.io.IOException  Description of Exception
   */
  final static int hexval(char c) throws java.io.IOException {
    switch (c) {
      case '0':
        return 0;
      case '1':
        return 1;
      case '2':
        return 2;
      case '3':
        return 3;
      case '4':
        return 4;
      case '5':
        return 5;
      case '6':
        return 6;
      case '7':
        return 7;
      case '8':
        return 8;
      case '9':
        return 9;
      case 'a':
      case 'A':
        return 10;
      case 'b':
      case 'B':
        return 11;
      case 'c':
      case 'C':
        return 12;
      case 'd':
      case 'D':
        return 13;
      case 'e':
      case 'E':
        return 14;
      case 'f':
      case 'F':
        return 15;
    }

    throw new java.io.IOException();
    // Should never come here
  }

}
