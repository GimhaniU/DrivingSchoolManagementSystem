Eltima Visual Java/SWING Components Library
README USER NOTICE

You're  now  reading  the  presentation  of  the  most advanced visual
components  library  for  Java developers. Eltima Java Components will
greatly  extend  the  set  of  components available in standard visual
library,  bringing  a whole lot of new ways to present your creativity
to  your  customers and clients. Make your software look different! No
routine coding � utilize your resources wisely!

Based  on  standard components, this collection supports all Java Look
and  Feel  such as Windows, Motif, Macintosh, etc, and adds new styles
to your software, buttons, color dialogs, search fields, and more. You
may  easily  integrate  Eltima  Java  Components  into  your  own Java
applications or applets.

Version details:
- Version of this package: 4.0
- Build of this package: 4.0.20
- Version released: December 29, 2006
- Build released: August 14, 2007

Eltima contacts:
- Technical support: support@eltima.com
- Sales team:        sales@eltima.com
- Phones:
  Germany:        +49 696 773 3496
  United Kingdom: +44 131 208 3240
  USA:            +1  360 312 7638

- Instant Messengers:
        ICQ #133156588
        MSN softinfinity@hotmail.com
        AIM SoftInfinitySP
        YAHOO serge_softinfinity
        JABBER Eltima@amessage.de/Trillian
        SKYPE eltima_ceo
- More information: www.eltima.com/products/visual-java-library
- Demo download: www.eltima.com/download/visual-java-library
- Get full version: www.eltima.com/purchase/visual-java-library

System requirements:
- Java Runtime 1.4.2 or above
- Any OS that supports Java Virtual Machine

What's new:
- Full support of new Java Platform 6
- Plenty of minor addings in almost every component
- Refreshed docs and samples
- Many bug fixes and minor enhancements

Detailed features:

Currently  Eltima  Java  Components  Library  includes  21 main visual
components  and  3  additional  types. Each of them has its own unique
features. Every component is described below:

- Table

A  very  powerful  component  which  lets you create multi-level table
headers, group lines by a specific column, collapse and expand groups,
automatically  count sums, averages, maximum/minimum values, etc. This
control features unique astonishing table customization menu which can
be  invoked even at runtime. This menu lets you configure not only the
visual  layout of your table, but plenty of internal settings as well,
like  sorting  by a definite column, showing/hiding columns, grouping,
text  orientation,  etc.  You  can also customize colors of any header
cell in your table: apply gradients and customizable fonts.

Since  version 2.9 you can enable search mode for the table, this lets
you  provide  advanced  filtering  and  searching capabilities to your
customers within our ELTable component. You can search not only in the
data  currently presented in the table, but also refer to the database
connected with the component.

- Table navigation toolbar

This  component  has  been  designed for ELTable component and greatly
extends  its  functionality. Navigation toolbar provides user-friendly
controls to navigate the entries that are visible in the table, add or
duplicate  these  entries,  delete rows, save or rollback changes, and
enable search mode for the table.

- Tabbed Pane

This  component is the alternative to JTabbedPane component which lets
you  create tabbed panels and switch them. In comparison with standard
component  ELTabbedPane lets you animate tab switching/selection, adds
support for custom images inside of the tab text and provides you with
more  control  on  their  placement. It also features Fade in/Fade out
effect  when  your  mouse  pointer  is  over  a  tab, also letting you
customize  the  colors  of selected and inactivated tabs. ELTabbedPane
also  features unique possibility to embed other JComponents into tabs
or create your own tabs with your own set of versatile components.

- Font Field

Modern  drop-down  font  selection  field  features  many configurable
settings  like background colors selection, gradients, font formatting
and more!

-  Borders

1)  Standard  border  with  rounded  angles. Can be raised or lowered,
depth  of  3D effect can be customized, as well as you can set all the
highlighting  and  shadow colors.

2)  The  same border with a title. The title can be placed on any side
(North,  West,  South,  East) of the border; colors, font face, layout
and alignment are fully customizable.

- Buttons

Cool   buttons   with  standard  functionality  and  greatly  enhanced
customizable  visual  presence.  Plenty  of  parameters to specify the
button design you need: shapes, colors, animation, etc.

- Color field

A  user-friendly  replacement  for  a  standard color selection dialog
which  handles  RGB  palette  with a lot of settings. You can set this
color  field  as a convenient popup to your edit field, selected color
is shown immediately, no need to popup additional windows or frames to
pick a color.

- ComboBox with search capability

An  enhanced  ComboBox that lets you search in a database and show the
whole table with its contents in a popup to your search field. You can
search from the beginning, at the end or anywhere in a database field.
Search  results  highlighting,  special  constructor to fill the table
automatically, filtering, and more.

- Date/Date SQL field

Full-featured  professional  customizable  calendar  control with time
selecting capabilities. This field can be used as a popup and features
plenty of ways to adjust the date selection process.

- Gradient panel and rectangle

Want  to  have a nice eye-catching gradient as a panel background? Use
this  component  to  setup a gradient automatically, just point to the
needed  colors,  direction,  layout,  etc.  Gradient  is automatically
redrawn on Window resize.

- Hyper-link button

Create nice hyper-link style buttons with this simple component!

- Image field

Has  plenty  of  settings  and  allows  image  manipulations: zooming,
rotating, opening, saving, moving, scrolling, and much more. It�s very
fast and really easy-to-use.

- Label

This control is an extension of the standard JLabel component and allows you
to set up background and foreground gradients.

- Calculator panel

Calculator panel is a simple component that provides all features that
standard PC calculator supplies.

- Calculator field

This is a combination of JFormattedTextField and ELCalculatorPanel components.
Simply type in the required equation and you will get the result directly in
this field.

Complete  editors  and  renderers  for  the majority of components are
already in the package.

Order now at www.eltima.com !